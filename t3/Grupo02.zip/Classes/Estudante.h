#ifndef ESTUDANTE_H_INCLUDED
#define ESTUDANTE_H_INCLUDED

// Incluindo a classe que ser� herdada
#include "Pessoa.h"

// Definindo o namespace
namespace poo{

    // Definindo a heran�a
    class Estudante: public Pessoa{

        friend ostream& operator<<(ostream&, const Estudante&);

        public:

            Estudante(string, string, int, double, double, double, double);
            ~Estudante();

            int getRA() const;
            double media() const;

            bool aprovado() const;
            bool sac() const;
            double notaSAC() const;

        private:

            const string nome, CPF;
            const int RA;
            const double notaP1, notaP2, notaT1, notaT2;

    };

}


#endif // ESTUDANTE_H_INCLUDED
